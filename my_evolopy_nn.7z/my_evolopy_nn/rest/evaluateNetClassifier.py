
from sklearn.metrics import confusion_matrix, accuracy_score
import numpy as np, time
debug = False
def put_weight_and_bias(values, model):
    num_neurons = []
    for layer in model.layers:
        num_neurons.append(layer.input_shape[1])
    num_neurons.append(model.layers[len(model.layers)  - 1].output_shape[1])
    start = 0
    for i in range(len(num_neurons) - 2):
        weight_matrix = np.array(values[ start: start + num_neurons[i] * num_neurons[i + 1] ])
        weight_matrix = weight_matrix.reshape((num_neurons[i], num_neurons[i + 1]))
        if debug: print(weight_matrix.shape)
        start += num_neurons[i] * num_neurons[i + 1]
        bias_vector = np.array(values[start:num_neurons[i + 1] + start])
        if debug: print(bias_vector)
        model.layers[i].set_weights([weight_matrix, bias_vector])
        start += num_neurons[i + 1]

    weight_matrix = np.array(values[ start: start+num_neurons[-2] * num_neurons[-1] ])
    weight_matrix = weight_matrix.reshape(num_neurons[-2], num_neurons[-1])
    start += num_neurons[-2] * num_neurons[-1]
    bias_vector = np.array(values[start:start+num_neurons[-1]])
    model.layers[-1].set_weights([weight_matrix, bias_vector])

    return model

def evaluateNetClassifier(solution,inputs,outputs,net):
    
    
    x = solution.bestIndividual
    
    printAcc = []
    
    trainInput = inputs
    trainOutput = outputs
    
    numInputs = np.shape(trainInput)[1] #number of inputs

    model = put_weight_and_bias(x, net)

    
    pred = net.predict(trainInput).reshape(len(trainOutput)) #transforming rows into cols i.e n x 1 as 1 x n
    mx = np.max(pred)
    pred = pred / mx
    pred = np.round(pred).astype(int)   
    trainOutput = trainOutput.astype(int) 

    

    ConfMatrix = confusion_matrix(trainOutput, pred)     
    ConfMatrix1D = ConfMatrix.flatten()
    

    printAcc.append(accuracy_score(trainOutput, pred,normalize=True)) 
    
    classification_results = np.concatenate((printAcc,ConfMatrix1D))
    # print(classification_results)
    return classification_results
    
    
    
    
