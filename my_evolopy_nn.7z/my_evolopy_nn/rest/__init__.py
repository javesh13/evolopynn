from . import BAT as bat
BAT = bat.BAT
from . import MFO as mfo
MFO = mfo.MFO
from . import MVO as mvo
MVO = mvo.MVO
from . import PSO as pso
PSO = pso.PSO
from . import GWO as gwo
GWO = gwo.GWO
from . import CS as cs
CS = cs.CS
from  . import evaluateNetClassifier as ev
evaluateNetClassifier = ev.evaluateNetClassifier
from .import fitness_functions
from . import solution as sltn
solution = sltn.solution

from . import sagregate_result as sr
from . import compute_classic_result
