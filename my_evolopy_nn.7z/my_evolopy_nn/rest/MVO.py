import random
import numpy
import time
import math
import sklearn
from numpy import asarray
from sklearn.preprocessing import normalize
from . import solution as sltn
solution = sltn.solution
  


def normr(Mat):
   """normalize the columns of the matrix
   B= normr(A) normalizes the row
   the dtype of A is float"""
   Mat=Mat.reshape(1, -1)
     # Enforce dtype float
   if Mat.dtype!='float':
      Mat = asarray(Mat,dtype=float)

   # if statement to enforce dtype float
   B = normalize(Mat,norm='l2',axis=1)
   B = numpy.reshape(B,-1)
   return B

def randk(t):
    if (t%2)==0:
        s=0.25
    else:
         s=0.75
    return s

def RouletteWheelSelection(weights):
  accumulation = numpy.cumsum(weights)
  p = random.random() * accumulation[-1]
  chosen_index = -1;
  for index in range (0, len(accumulation)):
    if (accumulation[index] > p):
      chosen_index = index;
      break;
  
  choice = chosen_index;

  return choice


def MVO(optimising_function, lb,ub,dim,N,Max_time,trainInput,trainOutput,net):
    "parameters"
    #dim=30
    #lb=-100
    #ub=100
    WEP_Max=1;
    WEP_Min=0.2
    #Max_time=1000
    #N=50
    
    
    
    
    Universes = numpy.random.uniform(0, 1, (N, dim)) * (ub - lb) + lb 
    #Universe is a two dimensional numpy array, dimensions N x dim, of random values from uniform distribution.

    #each value of numpy array is doubled and decremented by 

    #IDK why this is done

    Sorted_universes = numpy.copy(Universes)
    #this doesnot sorts the array it just copies the array.
    #so the name sorted_universes just fakes itself


    convergence = numpy.zeros(Max_time)
    #Max time = number of iterations
     
    
    Best_universe = [0]*dim
    #creates a list of zeroes having dim number of elements dim
    #the value of dim that has been passed from tha call in our case is: 
    #dim = 48 * (48 * 2 + 1) + 2 * ((48 * 2 + 1)) + 1 = 4851

    Best_universe_Inflation_rate = float("inf")
    #infinity value having type float.
    
    
    
    s = solution()
    iteration_number = 1  
    
    timerStart = time.time() 
    s.startTime = time.strftime("%Y-%m-%d-%H-%M-%S")
    while (iteration_number < Max_time+1):
        #Max_time means the number of iterations that has to be done. as defined in main.py0
        #iteration_number means present iteration
    
        "Eq. (3.3) in the paper"

        WEP = WEP_Min + iteration_number * ((WEP_Max - WEP_Min)/Max_time)
        #Worm hole existance probability
       
        TDR = 1 - (math.pow(iteration_number,1/6) / math.pow(Max_time,1/6))
        #TDR means Travelling distance rate
      
        Inflation_rates = [0]*len(Universes)
        
       
       
        for i in range(0,N):
            Universes[i,:] = numpy.clip(Universes[i,:], lb, ub)
            Inflation_rates[i] = optimising_function(Universes[i,:], trainInput, trainOutput, net)
            
                      
            if Inflation_rates[i] < Best_universe_Inflation_rate :
                Best_universe_Inflation_rate=Inflation_rates[i]
                Best_universe=numpy.array(Universes[i,:])
             
        
        sorted_Inflation_rates = numpy.sort(Inflation_rates)
        sorted_indexes = numpy.argsort(Inflation_rates)
        
        for newindex in range(0,N):
            Sorted_universes[newindex,:]=numpy.array(Universes[sorted_indexes[newindex],:])   
            
        normalized_sorted_Inflation_rates=numpy.copy(normr(sorted_Inflation_rates))
    
        
        Universes[0,:]= numpy.array(Sorted_universes[0,:])
    
        for i in range(1,N):
            Back_hole_index = i
            for j in range(0,dim):
                r1 = random.random()
                
                if r1 < normalized_sorted_Inflation_rates[i]:
                    White_hole_index = RouletteWheelSelection(-sorted_Inflation_rates)
    
                    if White_hole_index == -1:
                        White_hole_index = 0;

                    Universes[Back_hole_index,j] = Sorted_universes[White_hole_index,j];
            
                r2 = random.random() 
                
                
                if r2 < WEP:
                    r3 = random.random() 
                    if r3 < 0.5:                    
                        Universes[i,j] = Best_universe[j] + TDR * ((ub - lb) * random.random() + lb) #random.uniform(0,1)+lb);
                    if r3 > 0.5:          
                        Universes[i,j] = Best_universe[j] - TDR * ((ub - lb) * random.random() + lb) #random.uniform(0,1)+lb);
                              
        
        
        
        
        convergence[iteration_number - 1] = Best_universe_Inflation_rate
        #if (iteration_number%1==0):
        print(['At iteration '+ str(iteration_number)+ ' the best fitness is '+ str(Best_universe_Inflation_rate)])

        
        
        
        iteration_number=iteration_number+1
    timerEnd=time.time()  
    s.endTime=time.strftime("%Y-%m-%d-%H-%M-%S")
    s.executionTime=timerEnd-timerStart
    s.convergence=convergence
    s.optimizer="MVO"
    s.objfname=optimising_function.__name__
    s.bestIndividual=Best_universe

    return s
