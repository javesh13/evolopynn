import pandas as pd
import numpy as np
import sys

from sklearn.model_selection import train_test_split

if(len(sys.argv) < 2):
	print("program dataset_file_name")
	exit()
df =  pd.read_csv(sys.argv[1])


#df_new_train, df_new_test = train_test_split(df, test_size = , random_state = 13)

x_train , x_test = train_test_split(df, test_size = 0.30, random_state = 13)

x_train.to_csv(sys.argv[2]+"Train.csv", index = None, header = False)
x_test.to_csv(sys.argv[2]+"Test.csv", index = None, header = False)

