import pandas as pd
import numpy as np
import sys
from sklearn.model_selection import train_test_split
df =  pd.read_csv(sys.argv[1])

cols = df.columns

cols = cols[:-1]
#leaving the label column

for col  in cols:
    mean = np.mean(df[col])
    dev = np.std(df[col])
    df[col] = (df[col] - mean)/dev

df.to_csv(sys.argv[1]+"_norm.csv")
