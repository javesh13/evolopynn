import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
df =  pd.read_csv("IDS_norm.csv")

cols = df.columns

cols = cols[:-1]
#leaving the label column
rows = df.shape[0]
#cols = df.shape[1]

for col  in cols:
	for val in range(len(df[col])):
		df[col][val] = 0 if df[col][val] < 0.5 else 1

    # mean = np.mean(df[col])
    # dev = np.std(df[col])
    # df[col] = (df[col] - mean)/dev
df.head()

# df.to_csv("IDS_norm.csv")
