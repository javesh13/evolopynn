import pandas as pd
import numpy as np
df = pd.read_csv("weights.csv", header= None)

arr = df.values

arr = np.abs(arr)


np.savetxt("abs_weights.csv", arr, delimiter=",")

