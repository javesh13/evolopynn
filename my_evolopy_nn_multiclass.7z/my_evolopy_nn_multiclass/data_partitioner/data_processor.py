#!/usr/bin/python3
import pandas as pd
import numpy as np
import sys
from sklearn.model_selection import train_test_split




if(len(sys.argv) < 2):
	print("Usage processor dataset_1 dataset_2 ... ")
	print("donot include .csv after dataset name")
	print("Load path: ./raw_datasets/")
	print("Save path: .processed_datasets/")
	print("load data for crunching ../datasets/")
	exit()

print("splitting the dataset in 70% training and 30% testing")
load = "./raw_datasets/"
save = "./processed_datasets/"
crunch = "../datasets/" 

for dataset in sys.argv[1:]:
	load_name = load+dataset+".csv"

	df =  pd.read_csv(load_name)
	#leaving last column

	cols = df.columns
	cols = cols[:-1]
	#leaving the label column

	#scaling the data
	for col  in cols:
	    mean = np.mean(df[col])
	    dev = np.std(df[col])
	    df[col] = (df[col] - mean)/dev

	df.to_csv(save + dataset+"_norm.csv", index = None, header= False)
	df.to_csv(crunch+ dataset+"_norm.csv", index = None, header= False)
	


	x_train , x_test = train_test_split(df, test_size = 0.30, random_state = 13)

	x_train.to_csv(save+dataset+"_Train.csv", index = None, header = False)
	x_train.to_csv(crunch+dataset+"_Train.csv", index = None, header = False)
	x_test.to_csv(save+dataset+"_Test.csv", index = None, header = False)
	x_test.to_csv(crunch+dataset+"_Test.csv", index = None, header = False)


