driver.py 
it is the main driver program.
it runs the specified bio inspired algo and writes weights as weights_algo.csv in weights directory

sagregate_results.py
this program takes weights_algo.csv as input and produces the
reduced normalized dataset as output with name red_norm_algo.csv

compute_classic.py
this program evaluates the result of classic algorithms on dataset chosen and saves them in classic_result
