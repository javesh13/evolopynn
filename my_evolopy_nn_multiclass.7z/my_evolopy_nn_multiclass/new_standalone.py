import csv, numpy as np, time, sys, pandas as pd, math
import rest 
from keras.layers import Dense
from keras.models import Sequential
from keras.utils import plot_model


def mse_nn_multiclass(values, trainInput, trainOutput, model):
    
    model = compute_nn(values, model) 
    print("model has been pre trained here in mse_nn")
    model.fit(trainInput, trainOutput)

    pred = model.predict(trainInput)
    pred = numpy.argmax(pred, axis=1)
    orignal = numpy.argmax(trainOutput, axis=1)
    mse = ((pred - orignal) ** 2).mean(axis = None)
    return mse

df = pd.read_csv("ds_dataset.csv")

x = df.iloc[0:-1].values
y_ = df.iloc[-1].values

features = x.shape[1]	
num_classes = len(numpy.unique(y_))

# encode class values as integers
encoder = LabelEncoder()
encoder.fit(y_)
encoded_Y = encoder.transform(y_)
# convert integers to dummy variables (i.e. one hot encoded)
y = np_utils.to_categorical(encoded_Y)


# create model
#defining the number of layers
num_neurons = [features, 100, 130, 100, num_classes] 
#creating_model
model = Sequential() #creating model and adding layers
for i in range(len(num_neurons) - 2):#adding layers according to num_neurons
    model.add(Dense(num_neurons[i + 1], input_dim = num_neurons[i], activation = 'relu'))
model.add(Dense(num_neurons[-1]))#The last layer
# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

dim = 1
for i in range(len(num_neurons) - 2):
    dim += num_neurons[i] * num_neurons[i + 1] + num_neurons[i + 1]

dim += num_neurons[-2] * num_neurons[-1] + num_neurons[-1]

#data_formatting
x_train, x_test, y_train, y_test, y__train, y__test = train_test_split(x, y, y_, test_size = 0.20, random_state = seed)


def GWO(mse_nn_multiclass, lb,ub,dim,SearchAgents_no,Max_iter,trainInput,trainOutput, net):

population_size = 25
iterations= 5



answer = rest.GWO("function_to_be_made", -1, 1, dim, population_size, iterations, x, y, model)

