#!/usr/bin/python3
import csv, numpy as np, time, sys, pandas as pd, math
import rest 
from keras.layers import Dense
from keras.models import Sequential
from keras.utils import plot_model
import os
import traceback
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn import datasets
from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.metrics import accuracy_score


time_stamp = time.strftime("%Y-%m-%d-%H-%M-%S")
if (len(sys.argv) < 2):
    print("Usage")
    print("\t python this_program algo_name/algo_names dataset")
    print("\t algo name specified as GWO IDS")
    print("\t Example python diver.py MVO liver")
    exit()



verbose = False #verbose for verbose output
algorithm = {"MVO":rest.MVO, "BAT":rest.BAT, "CS":rest.CS, "MFO":rest.MFO, "PSO":rest.PSO, "GWO":rest.GWO}

##run parameters
function_to_be_optimised = rest.fitness_functions.mse_nn_multiclass
NumOfRuns = 1
PopulationSize = 25
Iterations = 5


Export = True #export results
CnvgHeader=[] # CSV Header for for the cinvergence 

for l in range(0,Iterations):
    CnvgHeader.append("Iter"+str(l + 1))



#getting data
def get_data(dataset_name):
    """
    This is the required shape of dataset.
                  feature_1 feature_2 ... feature_n output/label
    observation_1
    observation_2
    .
    .
    .
    observation_m
    """
    df = pd.read_csv(dataset_name, header=None).values

    inputs_train = df[:,0:-1]
    outputs_train = df[:, -1]
    return (inputs_train, outputs_train)

if(verbose): print("**********Loading Data")

dataset = sys.argv[-1]
dataset_train = dataset+"_Train.csv"
dataset_test = dataset + "_Test.csv"
dataset_complete = dataset+"_norm.csv"
path = "./datasets/"
train_input, train_output_ = get_data(path+dataset_train)
test_input, test_output_ = get_data(path+dataset_test)

print("debug*****************")
print(len(np.unique(train_output_)))
print(len(np.unique(test_output_)))
print("debug*****************")

ub = 1
lb = -1

encoder = LabelEncoder()
encoder.fit(test_output_)
encoded_Y = encoder.transform(test_output_)
# convert integers to dummy variables (i.e. one hot encoded)
test_output = np_utils.to_categorical(encoded_Y)


encoder = LabelEncoder()
encoder.fit(train_output_)
encoded_Y = encoder.transform(train_output_)
# convert integers to dummy variables (i.e. one hot encoded)
train_output = np_utils.to_categorical(encoded_Y)




num_classes = len(np.unique(test_output_))

if(verbose): print("********** Loading Data Done")

featuresTrain = train_input.shape[1]
featuresTest = test_input.shape[1]

if(featuresTrain != featuresTest):
    print("Number of features in train and test are not equal")
    exit()


num_classes = max(len(np.unique(test_output_)), len(np.unique(train_output_)))
print("Num of classes"+str(num_classes))

if(verbose): print("********** making  neural network")

features = featuresTrain
print("Number of features: ", features)
num_neurons = [features, 50, 100 ,50, num_classes] #defining the number of layers
model = Sequential() #creating model and adding layers
for i in range(len(num_neurons) - 2):#adding layers according to num_neurons
    model.add(Dense(num_neurons[i + 1], input_dim = num_neurons[i], activation = 'relu'))
model.add(Dense(num_neurons[-1], activation = 'softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy']) #compiling and generating Model
if(verbose): print(model.summary())

if(verbose): print("********** making neural network done")


dim = 1
for i in range(len(num_neurons) - 2):
    dim += num_neurons[i] * num_neurons[i + 1] + num_neurons[i + 1]

dim += num_neurons[-2] * num_neurons[-1] + num_neurons[-1]


def export_result(x, file_name):
    with open(file_name, 'a') as out:
        writer = csv.writer(out,delimiter=',')
        a = np.concatenate([[x.optimizer,dataset,x.objfname,k + 1,x.startTime,x.endTime,x.executionTime,x.trainAcc, x.trainTP,x.trainFN,x.trainFP,x.trainTN, x.testAcc, x.testTP,x.testFN,x.testFP,x.testTN],x.convergence])
        writer.writerow(a)

def write_header(file_name):
    with open(file_name, 'a') as out:
        writer = csv.writer(out,delimiter=',')
        header= np.concatenate([["Optimizer","Dataset","objfname","Experiment","startTime","EndTime","ExecutionTime","trainAcc", "trainTP","trainFN","trainFP","trainTN", "testAcc", "testTP","testFN","testFP","testTN"],CnvgHeader])
        writer.writerow(header)

save_path =  "./results/"
file_name_temp =  "pre_"+dataset+"_"+ time_stamp+".csv"

result_file_pre = open(save_path+file_name_temp, "w")
result_file_pre.write("Feature_selcetor_algo, Evaluation_algo,no_of_features,test_size,accuracy,precision,specificity,sensitivity,time_taken,\n")



n = os.fork()
if(n == 0):
    print("Computing accuracy without feature_selection")
    rest.compute_classic_result.init("none", result_file_pre, dataset_complete)
    print("********************************* Success from 1 ******************************************")
    #its an opened file
else:
    try:
        print("Computing accuracy without feature_selection done")
        for algo in sys.argv[1:-1]: #for each algorithm specified run and export result. last one is dataset
            result_file_post = open(save_path+"post_" + dataset + "_" + algo + "_" +time_stamp, "w")
            result_file_post.write("Feature_selcetor_algo, Evaluation_algo,no_of_features,test_size,accuracy,precision,specificity,sensitivity,time_taken,\n")




            if (verbose): print("********** Optimizing " + algo)
            file_name = "./results/" + algo + "_experiment_" + time_stamp +".csv" 
            write_header(file_name)

            for k in range (0,NumOfRuns):#different number of experiment/trials

                if(verbose): print("********** Running "+ str(k) + " Time")
               

                x = algorithm[algo](function_to_be_optimised, lb, ub, dim, PopulationSize, Iterations, train_input, train_output, model)
                

                trainClassification_results = rest.evaluateNetClassifier(x,train_input,train_output,model)
                
                if(verbose): print("Evaluated " + algo + " at run " + str(k) + " On train data")

                x.trainAcc, x.trainTP, x.trainFN, x.trainFP, x.trainTN = trainClassification_results[0:5]
          
               
                # Evaluate MLP classification model based on the testing set   
                testClassification_results = rest.evaluateNetClassifier(x, test_input, test_output, model)

                if(verbose): print("Evaluated " + algo + " at run " + str(k) + " On test data")

                x.testAcc, x.testTP, x.testFN, x.testFP , x.testTN = testClassification_results[0:5]
                
                export_result(x, file_name) 

            weights_and_bias = model.layers[0].get_weights()
            weights = weights_and_bias[0] #weight_matrix
            bias = weights_and_bias[1]#bias vector

            rows = weights.shape[0]
            cols = weights.shape[1]
            with open("weights/weights_"+algo+"_"+dataset+".csv", "w") as f:
                for i in range(rows):
                    for j in range(cols):
                        f.write(str(weights[i][j]))
                        if(j + 1 != cols):
                            f.write(",")
                    f.write("\n")
            
            print("generating reduced_datased")
            rest.sr.gen_database(algo, dataset)
            print("applying classic algorithms on redued_dataset")
            rest.compute_classic_result.init(algo, result_file_post, dataset)
    except Exception as     e:
        var = traceback.format_exc()
        print(var)
        print(e)
        print("HOOOOOOOOOOOOOOOOOO EXception")
        #close file after completeting all algos
        if(not result_file_pre.closed):
            result_file_pre.close()
        if(not result_file_post.closed):
            result_file_post.close()

