"""
Author: Vijay Bhardwaj
Date: 28-04-2018
"""

import numpy as np
debug = False

def compute_nn(values, model):
    num_neurons = []
    for layer in model.layers:
        num_neurons.append(layer.input_shape[1])
    num_neurons.append(model.layers[len(model.layers)  - 1].output_shape[1])
    start = 0
    for i in range(len(num_neurons) - 2):
        weight_matrix = np.array(values[ start: start + num_neurons[i] * num_neurons[i + 1] ])
        weight_matrix = weight_matrix.reshape((num_neurons[i], num_neurons[i + 1]))
        if debug: print(weight_matrix.shape)
        start += num_neurons[i] * num_neurons[i + 1]
        bias_vector = np.array(values[start:num_neurons[i + 1] + start])
        if debug: print(bias_vector)
        model.layers[i].set_weights([weight_matrix, bias_vector])
        start += num_neurons[i + 1]

    weight_matrix = np.array(values[ start: start+num_neurons[-2] * num_neurons[-1] ])
    weight_matrix = weight_matrix.reshape(num_neurons[-2], num_neurons[-1])
    start += num_neurons[-2] * num_neurons[-1]
    bias_vector = np.array(values[start:start+num_neurons[-1]])
    #apply yhe weights on nn
    model.layers[-1].set_weights([weight_matrix, bias_vector])

    #model is baked and ready for evaluation

    return model



def mse_nn(values, trainInput, trainOutput, model):
    
    model = compute_nn(values, model) 
    print("model has been pre trained here in mse_nn")
    model.fit(trainInput, trainOutput)
    pred = model.predict(trainInput)
    rows = pred.shape[0]
    pred = pred.reshape(rows,)
    mx = np.max(pred)
    pred = pred / mx
    pred = np.round(pred).astype(int)   
    trainOutput = trainOutput.astype(int) 

    mse = ((pred - trainOutput) ** 2).mean(axis = None)
    #this equaiton has been verified

    return mse

def diff_nn(values, trainInput, trainOutput, model):

    model = compute_nn(values, model)

    pred = model.predict(trainInput)
    rows = pred.shape[0]
    pred = pred.reshape(rows,)
    mx = np.max(pred)
    pred = pred / mx
    pred = np.round(pred).astype(int)   
    trainOutput = trainOutput.astype(int) 

    diff_score = 0

    for org, pred in zip(pred, trainOutput):
        if(org != pred):
            diff_score += 1

    return diff_score



def mse_nn_multiclass(values, trainInput, trainOutput, model):
    
    model = compute_nn(values, model) 
    print("model has been pre trained here in mse_nn")
    model.fit(trainInput, trainOutput)

    pred = model.predict(trainInput)
    pred = np.argmax(pred, axis=1)
    orignal = np.argmax(trainOutput, axis=1)
    mse = ((pred - orignal) ** 2).mean(axis = None)
    return mse


#we can define more fitness functions
