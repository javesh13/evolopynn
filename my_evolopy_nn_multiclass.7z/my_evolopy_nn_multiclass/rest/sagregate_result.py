import pandas as pd
import numpy as np

def gen_database(algo, dataset):

	df = pd.read_csv("./weights/weights_"+algo+"_"+dataset+".csv", header = None)
	df['avg'] = df.mean(axis = 1)

	avg = np.mean(df['avg'])

	bools = []
	for item in df['avg']:	
		bools.append(item >= avg)

	bools.append(True)#for result

	new_f = open("./reduced_datasets/dataset_reduced_"+algo+"_"+dataset+".csv", "w")

	with open("./datasets/"+dataset+"_norm.csv", "r")as f:
		for l in f.readlines():
			l = l.split(",")
			for i in range(len(l)):
				if(bools[i]):
					new_f.write(l[i])
					if(i + 1 != len(l)):
						new_f.write(",")

	new_f.close()