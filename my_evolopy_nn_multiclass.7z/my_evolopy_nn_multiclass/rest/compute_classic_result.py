import numpy as np, pandas as pd, time, sys
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import tree
class result:
    def __init__(self):
        self.feature_selection_algo = ""
        self.algo_name = ""
        self.num_feature = ""
        self.test_size = ""
        self.accuracy = ""
        self.precisoin = ""
        self.specificity = ""
        self.sensitivity = ""
        self.time_taken = ""



######declaring classifiers
knn = KNeighborsClassifier(n_neighbors =  42)#the magic_number:)
logreg = LogisticRegression()
rndm_clf = RandomForestClassifier(n_jobs = 2, random_state = 42)
dczn_tree = tree.DecisionTreeClassifier()
############
models = [knn]
model_names = ["KNeighborsClassifier"]

#models = [knn, logreg, rndm_clf, dczn_tree]
#model_names = ["KNeighborsClassifier", "Logistic Regression", "RandomForestClassifier", "DecisionTreeClassifier"]

def export_result(r, f):
    f.write(str(r.feature_selection_algo)+",")
    f.write(str(r.algo_name)+",")
    f.write(str(r.num_feature)+",")
    f.write(str(r.test_size)+"%"+",")
    f.write(str(r.accuracy)+",")
    f.write(str(r.precisoin)+",")
    f.write(str(r.specificity)+",")
    f.write(str(r.sensitivity)+",")
    f.write(str(r.time_taken)+",")
    f.write("\n")
    # f.close() dont close the file here
    







def perform_experiment(model_name, model, x, y, algo_name, file_name):
    r = result()
    r.algo_name  = model_name
    r.feature_selection_algo = algo_name
    print(x.shape)
    r.num_feature = x.shape[-1]

    start_time = time.time()
    for num in [0.3, 0.2]:
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = num, random_state = 42, stratify = y) 
        model.fit(x_train, y_train)
        r.test_size = str(num * 100)
        # print("Statistics of Model with test Size: " + str(num*100)+"% of data")
        
        y_predicted = model.predict(x_test)
        
        false_negative = 0
        false_positive = 0
        true_positive = 0
        true_negative = 0
        
        for i in range(len(y_test)):
            if y_test[i] == 0:
                if y_predicted[i] == 1:
                    false_positive += 1
                else:
                    true_positive += 1
            else:
                if y_predicted[i] == 0:
                    false_negative += 1
                else:
                    true_negative += 1
        
        #print(false_negative, false_positive, true_positive, true_negative)
        true_positive = float(true_positive)
        true_negative = float(true_negative)
        false_positive = float(false_positive)
        false_negative = float(false_negative)
        
        r.time_taken  = time.time() - start_time

        r.precisoin = (true_positive * 100)/(true_positive + false_positive)
        r.sensitivity = (true_positive*100)/(true_positive+false_negative)
        r.specificity = (true_negative*100)/(false_positive+true_negative)
        r.accuracy = ((true_positive+true_negative)*100)/(true_negative + true_positive + false_negative + false_positive)
        # print("Precision: %f" %((true_positive * 100)/(true_positive + false_positive)))
        # print("Sensitivity: %f" %()
        # print("Specificity: %f" %())
        # print("Accuracy: %f" %())
        export_result(r, file_name)

  
    



def init(algo = "none", file_name = "none", dataset = "IDS"):
    #file_name is an file descriptor to opened file
    if algo == "none":
        #doing for non reduced dataset

        df = pd.read_csv("./datasets/"+dataset)
    else:
        df = pd.read_csv("./reduced_datasets/dataset_reduced_"+algo+"_"+dataset+".csv")

    x = df.iloc[:, :-1].values
    y = df.iloc[:, len(df.columns) -1].values
    for i in range(len(models)):
        perform_experiment(model_names[i], models[i], x, y, algo, file_name)
    file_name.close()

